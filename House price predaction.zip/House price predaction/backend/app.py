from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import joblib
import pandas as pd

app = Flask(__name__, static_folder='../frontend', static_url_path='/')
CORS(app)
model = joblib.load('house_price_model.pkl')
feature_template = pd.read_csv("house_price_prediction_ap_large.csv").drop(['Price (₹)'], axis=1)
feature_template = pd.get_dummies(feature_template).iloc[0:1]

@app.route('/')
def home():
    return send_from_directory('../frontend', 'index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    try:
        area = float(data['features'][0])
        bedrooms = int(data['features'][1])
        location_value = int(data['features'][2])

        input_data = feature_template.copy()
        input_data.iloc[0] = 0
        input_data['Area (sq ft)'] = area
        input_data['Bedrooms'] = bedrooms

        location_col = f'Location_{location_value}'
        if location_col in input_data.columns:
            input_data[location_col] = 1

        prediction = model.predict(input_data)[0]
        return jsonify({"predicted_price": round(prediction, 2)})
        
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
