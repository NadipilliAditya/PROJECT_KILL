import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import os

# Load Dataset
dataset_path = os.path.join(os.path.dirname(__file__), "house_price_prediction_ap_large.csv")

try:
    df = pd.read_csv(dataset_path)
    print("✅ Dataset loaded successfully.")
except FileNotFoundError:
    print(f"❌ Error: Dataset file not found at {dataset_path}")
    exit()

# Data Preprocessing
df.dropna(inplace=True)

# Feature and Target Separation
X = df.drop(['Price ($)'], axis=1)
y = df['Price ($)']

# Encode Categorical Data (like 'Location')
X = pd.get_dummies(X)

# Split Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model Training
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Predictions & Accuracy
y_pred = model.predict(X_test)

# Accuracy Metrics
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
accuracy = r2 * 100  # R-squared interpreted as a percentage

print(f"📊 Mean Absolute Error: {mae:.2f}")
print(f"📊 Mean Squared Error: {mse:.2f}")
print(f"✅ Accuracy: {accuracy:.2f}%")

# Save Model
model_path = os.path.join(os.path.dirname(__file__), 'house_price_model.pkl')
joblib.dump(model, model_path)
print(f"💾 Model saved successfully at {model_path}")
