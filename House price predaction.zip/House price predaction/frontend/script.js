function showHome() {
    hideSections();
    document.getElementById("homeSection").style.display = "block";
}

function hideSections() {
    const sections = document.querySelectorAll(".section");
    sections.forEach(section => {
        section.style.display = "none";
    });
}

function showPredict() {
    hideSections();
    document.getElementById("predictSection").style.display = "block";
}

function showAboutUs() {
    hideSections();
    document.getElementById("aboutUsSection").style.display = "block";
}

function showContact() {
    hideSections();
    document.getElementById("contactSection").style.display = "block";
}

function predictPrice() {
    const area = parseFloat(document.getElementById("area").value);
    const bedrooms = parseFloat(document.getElementById("bedrooms").value); 
    const location = document.getElementById("location").value;

    if (area < 100 || isNaN(area)) {
        document.getElementById("result").innerText = "❌ Invalid area! Minimum area should be 100 sq ft.";
        return;
    }

    if (!Number.isInteger(bedrooms) || bedrooms <= 0) {
        document.getElementById("result").innerText = "❌ Invalid bedroom count! Bedrooms must be a whole number.";
        return;
    }

    const maxBedrooms = Math.floor((area - 100) / 50) + 1;
    if (bedrooms > maxBedrooms) {
        document.getElementById("result").innerText = 
            `❌ Unrealistic combination! Maximum ${maxBedrooms} bedrooms are allowed in ${area} sqft.`;
        return;
    }

    if (area === 100 && bedrooms === 2) {
        document.getElementById("result").innerText = "🛋️ Consider using compact furniture or space-saving designs for better utilization.";
        return;
    }

    const predictedPrice = (area * 1000) + (bedrooms * 50000);

    document.getElementById("result").innerText = `✅ Estimated Price: ₹${predictedPrice.toLocaleString()}`;
}

document.getElementById("predictPriceBtn").onclick = showPredict;
document.getElementById("aboutUsBtn").onclick = showAboutUs;
document.getElementById("contactUsBtn").onclick = showContact;

document.querySelectorAll('#backToHomeBtn').forEach(button => {
    button.addEventListener('click', function() {
        showHome();
    });
});

document.addEventListener("DOMContentLoaded", showHome);

